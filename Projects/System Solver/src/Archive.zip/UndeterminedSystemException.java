public class UndeterminedSystemException extends Exception {
	public UndeterminedSystemException() {
		super();
	}

	public UndeterminedSystemException(String message) {
		super(message);
	}
}
