class MissingVariableException extends Exception {
	public MissingVariableException() {
		super();
	}

	public MissingVariableException(String message) {
		super(message);
	}
}
